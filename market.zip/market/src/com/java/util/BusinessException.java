package com.java.util;

public class BusinessException extends BaseException {
    public BusinessException(String msg) {
        super(msg);
    }
}
